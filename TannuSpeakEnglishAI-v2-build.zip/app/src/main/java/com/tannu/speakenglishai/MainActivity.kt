package com.tannu.speakenglishai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var statusText: TextView
    private lateinit var heardText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        heardText = findViewById(R.id.heardText)

        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) tts.language = Locale.US
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { statusText.text = "Listening... बोलिए 🎙️" }
            override fun onBeginningOfSpeech() { statusText.text = "Listening..." }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText.text = "Checking your English..." }
            override fun onError(error: Int) {
                statusText.text = "Try again 🎤"
                Toast.makeText(this@MainActivity, "Please speak clearly and try again.", Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                heardText.text = if (text.isNotBlank()) "You said: $text" else "I couldn't hear you."
                statusText.text = "Great! Keep practicing 💪"
                if (text.isNotBlank()) speakReply(replyFor(text))
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        findViewById<Button>(R.id.speakBtn).setOnClickListener { startListening() }
        findViewById<Button>(R.id.lessonBtn).setOnClickListener {
            val lesson = "My name is Tannu. I am learning English. I practice every day."
            heardText.text = lesson
            speakReply(lesson)
        }
        findViewById<Button>(R.id.vocabBtn).setOnClickListener {
            val words = "Hello, Learn, Speak, Practice, Confident"
            heardText.text = words
            speakReply("Hello. Learn. Speak. Practice. Confident.")
        }
        findViewById<Button>(R.id.pronBtn).setOnClickListener {
            heardText.text = "Say: I am learning English."
            speakReply("I am learning English.")
        }
        findViewById<Button>(R.id.progressBtn).setOnClickListener {
            toast("Progress: Speaking practice started • Day 1")
        }
    }

    private fun startListening() {
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in English")
        }
        speechRecognizer.startListening(intent)
    }

    private fun replyFor(text: String): String {
        val lower = text.lowercase(Locale.US)
        return when {
            "hello" in lower || "hi" in lower -> "Hello! How are you today?"
            "how are you" in lower -> "I am fine. How about you?"
            "name" in lower -> "Nice to meet you! What do you like to do?"
            "thank" in lower -> "You are welcome! Keep practicing English."
            else -> "Good job! Keep speaking English. Can you say another sentence?"
        }
    }

    private fun speakReply(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tannu_reply")
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
